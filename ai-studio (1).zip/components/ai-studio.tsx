"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Check, DollarSign, Image, Share2, Video } from "lucide-react"
import { generateVideo, generateImage, createPost, shareVideo } from "@/lib/actions"

export default function AIStudio() {
  const [videoGenerated, setVideoGenerated] = useState(false)
  const [imageGenerated, setImageGenerated] = useState(false)
  const [userWallet, setUserWallet] = useState(0)
  const [adWallet, setAdWallet] = useState(0)
  const [autoShare, setAutoShare] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState<number | null>(null)
  const [content, setContent] = useState("")
  const [imagePrompt, setImagePrompt] = useState("")
  const [videoUrl, setVideoUrl] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [tags, setTags] = useState("")
  const [videoTitle, setVideoTitle] = useState("")
  const [thumbnail, setThumbnail] = useState("")
  const [isMonetized, setIsMonetized] = useState(false)
  const [isPublic, setIsPublic] = useState(false)
  const [balance, setBalance] = useState(0)
  const [isLoading, setIsLoading] = useState({
    video: false,
    image: false,
    post: false,
    share: false,
  })

  // Handle video generation
  const handleGenerateVideo = async () => {
    if (!content || !selectedAvatar) return

    setIsLoading({ ...isLoading, video: true })
    try {
      const result = await generateVideo(content, selectedAvatar)
      if (result.success) {
        setVideoGenerated(true)
        setVideoUrl(result.videoUrl)
        setVideoTitle(result.title)
        setThumbnail(result.thumbnail)
      }
    } catch (error) {
      console.error("Error generating video:", error)
    } finally {
      setIsLoading({ ...isLoading, video: false })
    }
  }

  // Handle image generation
  const handleGenerateImage = async () => {
    if (!imagePrompt) return

    setIsLoading({ ...isLoading, image: true })
    try {
      const result = await generateImage(imagePrompt)
      if (result.success) {
        setImageGenerated(true)
        setImageUrl(result.imageUrl)
      }
    } catch (error) {
      console.error("Error generating image:", error)
    } finally {
      setIsLoading({ ...isLoading, image: false })
    }
  }

  // Handle social media auto-share
  const handleShareOnSocialMedia = async () => {
    if (!videoGenerated) return

    setIsLoading({ ...isLoading, share: true })
    try {
      await shareVideo(videoUrl, videoTitle, tags, thumbnail)
      alert("Video shared successfully!")
    } catch (error) {
      console.error("Error sharing video:", error)
    } finally {
      setIsLoading({ ...isLoading, share: false })
    }
  }

  // Post content creation (video/image)
  const handleCreatePost = async (type: "video" | "image") => {
    setIsLoading({ ...isLoading, post: true })
    try {
      const postData = {
        content,
        tags,
        avatar: selectedAvatar,
        isMonetized,
        isPublic,
        videoUrl: type === "video" ? videoUrl : undefined,
        thumbnail: type === "video" ? thumbnail : undefined,
        imageUrl: type === "image" ? imageUrl : undefined,
      }

      const result = await createPost(postData)
      if (result.success) {
        alert("Post created successfully!")
      } else {
        alert("Error creating post")
      }
    } catch (error) {
      console.error("Error creating post:", error)
    } finally {
      setIsLoading({ ...isLoading, post: false })
    }
  }

  // Handle wallet updates for user and ads
  const addFundsToWallet = (amount: number, walletType: "user" | "ad") => {
    if (walletType === "user") {
      setUserWallet((prevBalance) => prevBalance + amount)
    } else if (walletType === "ad") {
      setAdWallet((prevBalance) => prevBalance + amount)
    }
  }

  // Handle payout when balance reaches $20
  const handlePayout = () => {
    if (userWallet >= 20) {
      setUserWallet((prevBalance) => prevBalance - 20)
      alert("Payout of $20 processed!")
    } else {
      alert("You need at least $20 to request a payout.")
    }
  }

  // Update balance display
  useEffect(() => {
    setBalance(userWallet + adWallet)
  }, [userWallet, adWallet])

  // Generate avatar array
  const avatars = Array.from({ length: 10 }, (_, i) => i + 1)

  return (
    <div className="space-y-8">
      <div className="flex flex-col items-center space-y-4">
        <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
          AI Studio - Content Creation Suite
        </h1>
        <p className="text-slate-300 text-center max-w-2xl">
          Create AI-generated videos and images, monetize your content, and manage your earnings all in one place.
        </p>
      </div>

      <Tabs defaultValue="content" className="w-full">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="content">Content Creation</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
          <TabsTrigger value="wallet">Wallet</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content Input</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="content">Video Content Prompt</Label>
                <Textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Describe the video you want to create..."
                  className="min-h-[120px]"
                />
                <div className="flex justify-between mt-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="monetization" checked={isMonetized} onCheckedChange={setIsMonetized} />
                    <Label htmlFor="monetization">Enable Monetization</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="public" checked={isPublic} onCheckedChange={setIsPublic} />
                    <Label htmlFor="public">Make Public</Label>
                  </div>
                </div>
                <Button
                  onClick={handleGenerateVideo}
                  disabled={!content || !selectedAvatar || isLoading.video}
                  className="w-full mt-2"
                >
                  {isLoading.video ? "Generating..." : "Generate Video"}
                  <Video className="ml-2 h-4 w-4" />
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="imagePrompt">Image Generation Prompt</Label>
                <Textarea
                  id="imagePrompt"
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder="Describe the image you want to create..."
                  className="min-h-[120px]"
                />
                <Button
                  onClick={handleGenerateImage}
                  disabled={!imagePrompt || isLoading.image}
                  className="w-full mt-2"
                >
                  {isLoading.image ? "Generating..." : "Generate Image"}
                  <Image className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Avatar Selection</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-4">
                {avatars.map((avatar) => (
                  <div
                    key={avatar}
                    className={`relative cursor-pointer transition-all ${
                      selectedAvatar === avatar ? "scale-110 ring-2 ring-primary rounded-full" : ""
                    }`}
                    onClick={() => setSelectedAvatar(avatar)}
                  >
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={`/placeholder.svg?height=64&width=64`} alt={`Avatar ${avatar}`} />
                      <AvatarFallback>A{avatar}</AvatarFallback>
                    </Avatar>
                    {selectedAvatar === avatar && (
                      <div className="absolute -top-1 -right-1 bg-primary rounded-full p-1">
                        <Check className="h-3 w-3 text-white" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview" className="space-y-6">
          {videoGenerated && (
            <Card>
              <CardHeader>
                <CardTitle>Video Preview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video bg-slate-950 rounded-lg overflow-hidden">
                  <video controls className="w-full h-full">
                    <source src={videoUrl || "/placeholder.svg?height=480&width=640"} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </div>
                <h3 className="text-xl font-semibold">{videoTitle || "Generated Video Title"}</h3>

                <div className="space-y-2">
                  <Label htmlFor="tags">Tags</Label>
                  <Input
                    id="tags"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="Enter tags separated by commas"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="autoShare" checked={autoShare} onCheckedChange={setAutoShare} />
                  <Label htmlFor="autoShare">Enable Auto Share on Social Media</Label>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button onClick={handleShareOnSocialMedia} disabled={isLoading.share} variant="outline">
                    {isLoading.share ? "Sharing..." : "Share Video"}
                    <Share2 className="ml-2 h-4 w-4" />
                  </Button>
                  <Button onClick={() => handleCreatePost("video")} disabled={isLoading.post}>
                    {isLoading.post ? "Creating..." : "Create Video Post"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {imageGenerated && (
            <Card>
              <CardHeader>
                <CardTitle>Generated Image</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video bg-slate-950 rounded-lg overflow-hidden flex items-center justify-center">
                  <img
                    src={imageUrl || "/placeholder.svg?height=480&width=640"}
                    alt="Generated Image"
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                <Button onClick={() => handleCreatePost("image")} disabled={isLoading.post}>
                  {isLoading.post ? "Creating..." : "Create Image Post"}
                </Button>
              </CardContent>
            </Card>
          )}

          {!videoGenerated && !imageGenerated && (
            <div className="flex flex-col items-center justify-center py-12 text-slate-400">
              <div className="mb-4">
                <Image className="h-16 w-16 opacity-30" />
              </div>
              <p>Generate content to see a preview here</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="wallet" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Wallet Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-slate-800">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center">
                      <DollarSign className="h-8 w-8 text-green-400 mb-2" />
                      <h3 className="text-lg font-medium">User Wallet</h3>
                      <p className="text-3xl font-bold">${userWallet.toFixed(2)}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center">
                      <DollarSign className="h-8 w-8 text-blue-400 mb-2" />
                      <h3 className="text-lg font-medium">Ad Wallet</h3>
                      <p className="text-3xl font-bold">${adWallet.toFixed(2)}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center">
                      <DollarSign className="h-8 w-8 text-purple-400 mb-2" />
                      <h3 className="text-lg font-medium">Total Balance</h3>
                      <p className="text-3xl font-bold">${balance.toFixed(2)}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button onClick={() => addFundsToWallet(5, "user")} variant="outline">
                    Add $5 to User Wallet
                  </Button>
                  <Button onClick={() => addFundsToWallet(5, "ad")} variant="outline">
                    Add $5 to Ad Wallet
                  </Button>
                </div>

                <Button onClick={handlePayout} disabled={userWallet < 20} className="w-full" variant="default">
                  Request Payout
                  {userWallet < 20 && (
                    <Badge variant="outline" className="ml-2">
                      Need ${(20 - userWallet).toFixed(2)} more
                    </Badge>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

